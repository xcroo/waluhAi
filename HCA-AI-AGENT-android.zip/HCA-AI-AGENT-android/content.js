class AIReplyGenerator {
  constructor() {
    this.tones = [
      { label: "Like", value: "like" },
      { label: "Support", value: "support" },
      { label: "Dislike", value: "dislike" },
      { label: "Suggest", value: "suggestion" },
      { label: "Ask", value: "question" }
    ];

    this.apiKey = "";
    this.mode = "casual";
    
    // Load awal
    chrome.storage.local.get(["apiKey", "mode"], (result) => {
      this.apiKey = result.apiKey || "";
      this.mode = result.mode || "casual";
      this.apiEndpoint = `https://api.openai.com/v1/chat/completions`;
      this.startObserver();
    });

    // Listener update real-time
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "updateApiKeyAndMode") {
        this.apiKey = message.apiKey || this.apiKey;
        this.mode = message.mode || this.mode;
        sendResponse({ status: "success" });
      }
    });
  }

  // --- 1. OBSERVER (Mencari toolbar tweet) ---
  startObserver() {
    const observer = new MutationObserver((mutations) => {
      const toolbars = document.querySelectorAll('[data-testid="toolBar"]');
      toolbars.forEach((toolbar) => {
        const parent = toolbar.parentElement;
        if (parent && !parent.querySelector('.ai-tone-bar')) {
          const tweetText = this.findTweetContext(toolbar);
          const toneBar = this.createToneBar(tweetText);
          parent.insertBefore(toneBar, toolbar);
        }
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  findTweetContext(element) {
    let article = element.closest('article');
    if (!article) {
        const modal = element.closest('[role="dialog"]') || document.querySelector('main');
        if (modal) {
             const allTweets = modal.querySelectorAll('[data-testid="tweetText"]');
             if (allTweets.length > 0) return allTweets[0].innerText;
        }
    } else {
        return article.querySelector('[data-testid="tweetText"]')?.innerText || "";
    }
    return "";
  }

  // --- 2. DETEKSI BAHASA ---
  detectLanguage(text) {
    const chinesePattern = /[\u4e00-\u9fff]/;
    const japanesePattern = /[\u3040-\u309f\u30a0-\u30ff]/;
    const koreanPattern = /[\uac00-\ud7af]/;
    const arabicPattern = /[\u0600-\u06ff]/;
    const thaiPattern = /[\u0e00-\u0e7f]/;
    const cyrillicPattern = /[\u0400-\u04ff]/;
    
    if (chinesePattern.test(text)) return 'chinese';
    if (japanesePattern.test(text)) return 'japanese';
    if (koreanPattern.test(text)) return 'korean';
    if (arabicPattern.test(text)) return 'arabic';
    if (thaiPattern.test(text)) return 'thai';
    if (cyrillicPattern.test(text)) return 'russian';
    return 'english';
  }

  // --- 3. INSTRUKSI BAHASA (LENGKAP) ---
  getLanguageInstruction(language, mode) {
    const languageInstructions = {
      chinese: {
        name: "Simplified Chinese (简体中文)",
        casual: "使用轻松、自然的中文回复，就像朋友之间的对话。可以使用网络流行语和表情包文化的表达方式。保持简短有力，符合年轻人的说话方式。",
        formal: "使用正式、专业的中文，适合商务或官方交流。用词准确，语气礼貌得体。",
        friendly: "使用温暖、亲切的中文，营造友好的氛围。语气真诚，让人感到舒适。"
      },
      japanese: {
        name: "Japanese (日本語)",
        casual: "カジュアルで自然な日本語で返信してください。友達同士の会話のように、リラックスした口調で。ネットスラングや若者言葉を適度に使ってOK。短くてパンチのある文章で。",
        formal: "丁寧で礼儀正しい日本語を使用してください。ビジネスや公式な場にふさわしい言葉遣いで、敬語を適切に使用してください。",
        friendly: "親しみやすく温かい日本語で、相手との距離を縮めるような口調で返信してください。優しく共感的な表現を使ってください。"
      },
      korean: {
        name: "Korean (한국어)",
        casual: "편안하고 자연스러운 한국어로 답장하세요. 친구들끼리 대화하는 것처럼 캐주얼하게. 인터넷 용어나 줄임말을 적절히 사용해도 좋습니다. 짧고 임팩트 있게.",
        formal: "격식있고 전문적인 한국어를 사용하세요. 비즈니스나 공식적인 커뮤니케이션에 적합하게 존댓말을 사용하세요.",
        friendly: "따뜻하고 친근한 한국어로, 상대방과 친밀감을 형성할 수 있는 어조로 답장하세요. 공감적이고 부드러운 표현을 사용하세요."
      },
      arabic: {
        name: "Arabic (العربية)",
        casual: "استخدم اللغة العربية بطريقة عفوية وطبيعية، كأنك تتحدث مع صديق. يمكن استخدام التعبيرات العامية المناسبة. اجعل الرد قصيراً ومؤثراً.",
        formal: "استخدم اللغة العربية الفصحى بأسلوب رسمي ومهني، مناسب للتواصل التجاري أو الرسمي.",
        friendly: "استخدم لغة عربية دافئة وودية، تبني علاقة طيبة وتشعر القارئ بالراحة."
      },
      thai: {
        name: "Thai (ไทย)",
        casual: "ใช้ภาษาไทยแบบสบายๆ เป็นกันเอง เหมือนคุยกับเพื่อน ใช้คำสแลงหรือภาษาเน็ตได้ตามความเหมาะสม สั้นกระชับ มีพลัง",
        formal: "ใช้ภาษาไทยที่สุภาพเป็นทางการ เหมาะกับการสื่อสารในธุรกิจหรือการทำงาน ใช้คำราชาศัพท์ตามความเหมาะสม",
        friendly: "ใช้ภาษาไทยที่อบอุ่น เป็นมิตร สร้างความรู้สึกผูกพัน ใช้น้ำเสียงที่จริงใจและเห็นอกเห็นใจ"
      },
      russian: {
        name: "Russian (Русский)",
        casual: "Используй непринужденный, естественный русский язык, как в разговоре с друзьями. Можно использовать интернет-сленг. Коротко и по делу.",
        formal: "Используй формальный, профессиональный русский язык, подходящий для делового или официального общения.",
        friendly: "Используй теплый, дружелюбный русский язык, создающий доверительную атмосферу."
      },
      english: {
        name: "English",
        casual: "Write a fun, catchy, and easy-to-understand copy using casual, slangy English. The tone should be playful, relaxed, and sound like you're talking to a friend. Keep the sentences short and punchy. Make sure the message is clear and engaging for young adults (18-30). Avoid formal words, and feel free to use popular slang or expressions from social media.",
        formal: "Use a formal and professional tone, suitable for business or official communication.",
        friendly: "Use a warm, approachable tone, suitable for building rapport or encouragement."
      }
    };

    const langConfig = languageInstructions[language] || languageInstructions.english;
    return langConfig[mode] || langConfig.casual;
  }

  // --- 4. API LOGIC (Dengan Auto-Fetch Key) ---
  async getAIReply(tweetText, tone) {
    // Cek API Key di memori, kalau kosong tarik dari storage
    if (!this.apiKey) {
        await new Promise(resolve => {
            chrome.storage.local.get(['apiKey'], (result) => {
                this.apiKey = result.apiKey || "";
                resolve();
            });
        });
    }

    if (!this.apiKey) {
        alert("Please SAVE your API Key in settings first!");
        return null;
    }

    const detectedLanguage = this.detectLanguage(tweetText);
    const languageInstruction = this.getLanguageInstruction(detectedLanguage, this.mode);

    // Format instruksi
    let formatInstructions = detectedLanguage === 'english' 
      ? "- Stick to simple punctuation. No capital letters at start. Avoid contractions. Casual style." 
      : "- Use natural native conversational style and punctuation.";

    const prompt = `
      Analyze this tweet and generate a reply.
      Tweet: "${tweetText}"
      Detected Language: ${detectedLanguage}
      Tone: ${tone}

      Instructions:
      - Reply in the SAME LANGUAGE as the tweet (${detectedLanguage}).
      - Keep it under 280 characters.
      - ${languageInstruction}
      - ${formatInstructions}
    `;

    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: "You are a helpful social media assistant." },
            { role: "user", content: prompt }
          ],
          max_tokens: 150
        })
      });

      if (!response.ok) {
          const errData = await response.json();
          if (errData.error) {
              alert(`OpenAI Error: ${errData.error.message}`);
              throw new Error(errData.error.message);
          }
          throw new Error("API Connection Failed");
      }

      const data = await response.json();
      let reply = data.choices[0].message.content || "Nice!";
      
      // Bersihkan tanda kutip dan hashtag berlebihan
      reply = reply.replace(/^["']|["']$/g, '').trim(); 
      return reply;

    } catch (error) {
      console.error(error);
      return null;
    }
  }

  // --- 5. UI MOBILE (Scrollable) ---
  createToneBar(tweetText) {
    const container = document.createElement("div");
    container.className = "ai-tone-bar";
    
    Object.assign(container.style, {
      display: "flex",
      overflowX: "auto",
      gap: "8px",
      padding: "8px 4px",
      marginBottom: "5px",
      scrollbarWidth: "none"
    });

    this.tones.forEach(tone => {
      const btn = document.createElement("button");
      const icon = tone.value === "like" ? "👍" : tone.value === "support" ? "🤝" : tone.value === "dislike" ? "👎" : tone.value === "suggestion" ? "💡" : "❓";
      btn.innerHTML = `${icon} <span style="font-size:12px">${tone.label}</span>`;
      
      Object.assign(btn.style, {
        padding: "6px 12px",
        border: "1px solid #536471",
        borderRadius: "20px",
        background: "rgba(21, 32, 43, 0.9)",
        color: "#fff",
        fontSize: "14px",
        fontWeight: "bold",
        whiteSpace: "nowrap",
        flexShrink: "0"
      });

      btn.onmousedown = (e) => e.preventDefault(); 
      
      btn.onclick = async (e) => {
        e.preventDefault();
        e.stopPropagation();

        const originalText = btn.innerHTML;
        btn.innerHTML = "⏳...";
        btn.style.opacity = "0.7";
        
        const reply = await this.getAIReply(tweetText, tone.value);
        if (reply) {
            await this.injectReplyText(reply);
        }
        
        btn.innerHTML = originalText;
        btn.style.opacity = "1";
      };

      container.appendChild(btn);
    });

    return container;
  }

  // --- 6. AGGRESSIVE PASTE (Agar muncul di HP) ---
  async injectReplyText(text) {
    const replyBox = document.querySelector('[data-testid="tweetTextarea_0"]') || 
                     document.querySelector('div[contenteditable="true"]');
    
    if (!replyBox) return;

    replyBox.focus();
    replyBox.click();

    // Cara paling aman di Mobile (ExecCommand)
    const success = document.execCommand('insertText', false, text);

    if (!success) {
        // Fallback manual jika execCommand ditolak browser
        const span = replyBox.querySelector('[data-text="true"]');
        if (span) span.innerText = text;
        else replyBox.innerText = text;

        replyBox.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }
}

new AIReplyGenerator();