# HCA-AI-AGENT

`Generate Smart Twitter Replies with AI`

This extension is designed to generate context-based replies for Twitter posts using AI.

## Installation

1. Extract the `HCA-AI-AGENT.zip` file.
2. Open your browser, navigate to `Manage Extensions`, and enable `Developer Mode`.
3. Click `Load Unpacked`, then select the extracted `HCA-AI-AGENT` folder.
4. Open the extension settings, enter your Gemini API key, and save.
   - If the default response persists or the mode doesn't change, edit the `content.js` file in the `HCA-AI-AGENT` folder and reload the extension.

## Usage

1. Click the `Reply` button on the target Twitter post.
2. Select from the available tones.
3. Choose the desired tone and let the AI generate the reply.

## Contributing

Feel free to contribute by:
- Integrating different AI models.
- Adding new logic to enhance the extension's functionality.

## Important Note

Please do not distribute this extension, as similar tools like Qura.ai, Reply.so, and Olly Social are paid services.