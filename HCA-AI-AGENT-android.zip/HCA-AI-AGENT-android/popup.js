document.addEventListener('DOMContentLoaded', () => {
  const apiKeyInput = document.getElementById('apiKeyInput');
  const saveButton = document.getElementById('saveButton');
  const statusMessage = document.getElementById('statusMessage');
  const formalToggle = document.getElementById('formalToggle');
  const casualToggle = document.getElementById('casualToggle');
  const friendlyToggle = document.getElementById('friendlyToggle');

  // Load data saat popup dibuka
  chrome.storage.local.get(['apiKey', 'mode'], (result) => {
    if (result.apiKey) apiKeyInput.value = result.apiKey;
    if (result.mode) {
      const toggle = document.querySelector(`#${result.mode}Toggle`);
      if (toggle) toggle.checked = true;
    } else {
      if (casualToggle) casualToggle.checked = true;
    }
  });

  saveButton.addEventListener('click', () => {
    const apiKey = apiKeyInput.value.trim();
    const mode = document.querySelector('input[name="mode"]:checked')?.id.replace('Toggle', '') || 'casual';

    if (apiKey) {
      // 1. Simpan ke Storage (Penyimpanan Browser)
      chrome.storage.local.set({ apiKey, mode }, () => {
        // Tampilkan pesan sukses DULUAN agar user tenang
        statusMessage.textContent = 'Settings saved!';
        statusMessage.className = 'status-message success';
        setTimeout(() => statusMessage.textContent = '', 2000);

        // 2. Coba kirim ke Tab aktif (Pakai error handling)
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0] && tabs[0].id) {
            chrome.tabs.sendMessage(tabs[0].id, { action: "updateApiKeyAndMode", apiKey, mode }, (response) => {
              // Abaikan error jika tab bukan Twitter atau script belum siap
              if (chrome.runtime.lastError) {
                 console.log("Data saved to storage (Tab update skipped)");
              }
            });
          }
        });
      });
    } else {
      statusMessage.textContent = 'Enter API Key first!';
      statusMessage.className = 'status-message error';
    }
  });
});